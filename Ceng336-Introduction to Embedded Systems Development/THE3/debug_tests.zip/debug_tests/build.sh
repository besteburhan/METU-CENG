cd ..
make -f Makefile clean
make -f Makefile all
